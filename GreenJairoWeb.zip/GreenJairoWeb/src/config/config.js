require('dotenv').config();

module.exports = {
    app: {
        port: process.env.PORT || 3060 ,
    },
    mysql: {
        host: process.env.MYSQL_HOST || "localhost",
        user: process.env.MYSQL_USER || "glazed",
        password: process.env.MYSQL_PASS || "alpine",
        database: process.env.MYSQL_DATABASE || "green_jairo"
    }
}